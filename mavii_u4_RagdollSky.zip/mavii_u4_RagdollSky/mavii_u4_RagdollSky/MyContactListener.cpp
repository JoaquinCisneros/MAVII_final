#include "MyContactListener.h"
MyContactListener::MyContactListener() : victoryDetected(false) {}

void MyContactListener::BeginContact(b2Contact* contact) {
    b2Fixture* fixtureA = contact->GetFixtureA();
    b2Fixture* fixtureB = contact->GetFixtureB();

    b2Body* bodyA = fixtureA->GetBody();
    b2Body* bodyB = fixtureB->GetBody();

    const char* typeA = reinterpret_cast<const char*>(bodyA->GetUserData().pointer);
    const char* typeB = reinterpret_cast<const char*>(bodyB->GetUserData().pointer);

    if (!typeA || !typeB) return;

    if ((strcmp(typeA, "ragdoll") == 0 && strcmp(typeB, "target") == 0) ||
        (strcmp(typeA, "target") == 0 && strcmp(typeB, "ragdoll") == 0)) {
        victoryDetected = true;  // Solo ponemos la bandera, del flujo se encarga la clase game
    }
}