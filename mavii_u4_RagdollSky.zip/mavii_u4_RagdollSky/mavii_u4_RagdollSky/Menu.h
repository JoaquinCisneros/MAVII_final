#pragma once
#include "GameState.h"
#include <SFML/Graphics.hpp>
#include <iostream>

class Menu {
public:
    Menu();
    void draw(sf::RenderWindow& wnd);
    void handleInput(sf::Event& event, GameState& state, sf::RenderWindow& window);

private:
    sf::Font font;
    sf::Text playText;
    sf::Text exitText;
};
