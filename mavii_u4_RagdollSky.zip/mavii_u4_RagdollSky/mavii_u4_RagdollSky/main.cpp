#include "Game.h"

using namespace std;

int main() {

	Game myGame(800, 600, "titulillo");
	myGame.Loop();

	return 0;
}