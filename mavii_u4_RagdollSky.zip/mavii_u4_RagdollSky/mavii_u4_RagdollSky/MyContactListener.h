#pragma once
#include <box2d/box2d.h>
#include <iostream>
#include <cstring>
class MyContactListener : public b2ContactListener {
private:
    bool victoryDetected = false;
public:
    // Constructor
    MyContactListener();

    // Override
    void BeginContact(b2Contact* contact) override;

    // Getter para consultar si hubo victoria
    bool IsVictoryDetected() const { return victoryDetected; }

    // Para resetear la bandera despu�s de manejar la victoria
    void ResetVictoryFlag() { victoryDetected = false; }
};
