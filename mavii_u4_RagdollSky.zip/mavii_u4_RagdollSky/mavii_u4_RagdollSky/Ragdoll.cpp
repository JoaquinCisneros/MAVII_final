#include "Ragdoll.h"

Ragdoll::Ragdoll(b2World* phyWorld, const b2Vec2& position) : world(phyWorld) {

    //Cuerpo

    headBody = Box2DHelper::CreateRectangularDynamicBody(world, 1.0f, 1.0f, 0.4f, 0.3f, 0.1f);
    headBody->SetTransform(b2Vec2(position.x, position.y - 3), 0.0f);
    headBody->GetUserData().pointer = reinterpret_cast<uintptr_t>("ragdoll");

    trunkBody = Box2DHelper::CreateRectangularDynamicBody(world, 2.0f, 4.0f, 0.4f, 0.0f, 0.1f);
    trunkBody->SetTransform(b2Vec2(position), 0.0f);
    trunkBody->GetUserData().pointer = reinterpret_cast<uintptr_t>("ragdoll");

    leftArmBody = Box2DHelper::CreateRectangularDynamicBody(world, 1.0f, 2.0f, 0.4f, 0.0f, 0.1f);
    leftArmBody->SetTransform(b2Vec2(position.x - 2, position.y), 0.0f);
    leftArmBody->GetUserData().pointer = reinterpret_cast<uintptr_t>("ragdoll");

    rightArmBody = Box2DHelper::CreateRectangularDynamicBody(world, 1.0f, 2.0f, 0.4f, 0.0f, 0.1f);
    rightArmBody->SetTransform(b2Vec2(position.x + 2, position.y), 0.0f);
    rightArmBody->GetUserData().pointer = reinterpret_cast<uintptr_t>("ragdoll");

    leftLegBody = Box2DHelper::CreateRectangularDynamicBody(world, 1.2f, 4.0f, 0.4f, 0.0f, 0.1f);
    leftLegBody->SetTransform(b2Vec2(position.x -0.5f, position.y + 4), 0);
    leftLegBody->GetUserData().pointer = reinterpret_cast<uintptr_t>("ragdoll");

    rightLegBody = Box2DHelper::CreateRectangularDynamicBody(world, 1.2f, 4.0f, 0.4f, 0.0f, 0.1f);
    rightLegBody->SetTransform(b2Vec2(position.x +0.5f, position.y +4), 0);
    rightLegBody->GetUserData().pointer = reinterpret_cast<uintptr_t>("ragdoll");

    //Seteo los data para detectar la colision


    //Joints

    headJoint = Box2DHelper::CreateDistanceJoint(world, trunkBody, b2Vec2(trunkBody->GetPosition().x, trunkBody->GetPosition().y - 2),
        headBody, b2Vec2(headBody->GetPosition().x, headBody->GetPosition().y + 0.5f), 0.5f, 1.0f, 1.0f);

    leftArmJoint = Box2DHelper::CreateDistanceJoint(world, trunkBody, b2Vec2(trunkBody->GetPosition().x - 1, trunkBody->GetPosition().y - 2),
        leftArmBody, b2Vec2(leftArmBody->GetPosition().x, leftArmBody->GetPosition().y - 1), 0.5f, 1.0f, 1.0f);

    rightArmJoint = Box2DHelper::CreateDistanceJoint(world, trunkBody, b2Vec2(trunkBody->GetPosition().x + 1, trunkBody->GetPosition().y - 2),
        rightArmBody, b2Vec2(rightArmBody->GetPosition().x, rightArmBody->GetPosition().y - 1), 0.5f, 1.0f, 1.0f);

    leftLegJoint = Box2DHelper::CreateDistanceJoint(world, trunkBody, b2Vec2(trunkBody->GetPosition().x - 1, trunkBody->GetPosition().y + 2),
        leftLegBody, b2Vec2(leftLegBody->GetPosition().x, leftLegBody->GetPosition().y - 1.5f), 0.5f, 1.0f, 1.0f);

    rightLegJoint = Box2DHelper::CreateDistanceJoint(world, trunkBody, b2Vec2(trunkBody->GetPosition().x + 1, trunkBody->GetPosition().y + 2),
        rightLegBody, b2Vec2(rightLegBody->GetPosition().x, rightLegBody->GetPosition().y - 1.5f), 0.5f, 1.0f, 1.0f);


    //SFML
    if (!t_Body.loadFromFile("Assets/Sprites/Pecho.png"))
        std::cout << "Error: No se pudo cargar Assets/Sprites/Pecho.png\n";

    if (!t_Head.loadFromFile("Assets/Sprites/Cabeza.png"))
        std::cout << "Error: No se pudo cargar Assets/Sprites/Cabeza.png\n";

    if (!t_Arm.loadFromFile("Assets/Sprites/Brazo.png"))
        std::cout << "Error: No se pudo cargar Assets/Sprites/Brazo.png\n";

    if (!t_Leg.loadFromFile("Assets/Sprites/Pierna.png"))
        std::cout << "Error: No se pudo cargar Assets/Sprites/Pierna.png\n";

    s_Body.setTexture(t_Body);
    s_Head.setTexture(t_Head);
    s_Larm.setTexture(t_Arm);
    s_Rarm.setTexture(t_Arm);
    s_Lleg.setTexture(t_Leg);
    s_Rleg.setTexture(t_Leg);

    //Seteamos los origenes en el medio del sprite, para que matchee con box2d

    s_Head.setOrigin(t_Head.getSize().x / 2.f, t_Head.getSize().y / 2.f);
    s_Body.setOrigin(t_Body.getSize().x / 2.f, t_Body.getSize().y / 2.f);
    s_Larm.setOrigin(t_Arm.getSize().x / 2.f, t_Arm.getSize().y / 2.f);
    s_Rarm.setOrigin(t_Arm.getSize().x / 2.f, t_Arm.getSize().y / 2.f);
    s_Lleg.setOrigin(t_Leg.getSize().x / 2.f, t_Leg.getSize().y / 2.f);
    s_Rleg.setOrigin(t_Leg.getSize().x / 2.f, t_Leg.getSize().y / 2.f);

    // Obtener el tama�o de cada cuerpo f�sico (Box2D)
    sf::Vector2f headSize(1.0f, 1.0f); // Cabeza
    sf::Vector2f trunkSize(2.0f, 4.0f); // Tronco
    sf::Vector2f leftArmSize(1.0f, 2.0f); // Brazo izquierdo
    sf::Vector2f rightArmSize(1.0f, 2.0f); // Brazo derecho
    sf::Vector2f leftLegSize(1.2f, 4.0f); // Pierna izquierda
    sf::Vector2f rightLegSize(1.2f, 4.0f); // Pierna derecha

    // Escalar los sprites seg�n el tama�o de los cuerpos f�sicos
    s_Head.setScale(headSize.x / t_Head.getSize().x, headSize.y / t_Head.getSize().y);
    s_Body.setScale(trunkSize.x / t_Body.getSize().x, trunkSize.y / t_Body.getSize().y);
    s_Larm.setScale(leftArmSize.x / t_Arm.getSize().x, leftArmSize.y / t_Arm.getSize().y);
    s_Rarm.setScale(rightArmSize.x / t_Arm.getSize().x, rightArmSize.y / t_Arm.getSize().y);
    s_Lleg.setScale(leftLegSize.x / t_Leg.getSize().x, leftLegSize.y / t_Leg.getSize().y);
    s_Rleg.setScale(rightLegSize.x / t_Leg.getSize().x, rightLegSize.y / t_Leg.getSize().y);

}

void Ragdoll::ApplyForceToBody(b2Vec2& force) {
    trunkBody->ApplyForceToCenter(b2Vec2(force), true);
}

void Ragdoll::Draw(RenderWindow& w) {
    w.draw(s_Head);
    w.draw(s_Body);
    w.draw(s_Larm);
    w.draw(s_Rarm);
    w.draw(s_Lleg);
    w.draw(s_Rleg);
    //std::cout << "Dibujando sprites..." << std::endl;
}

void Ragdoll::Update() {



    // Cabeza
    s_Head.setPosition(headBody->GetPosition().x, headBody->GetPosition().y);
    s_Head.setRotation(headBody->GetAngle() * 180 / b2_pi);

    // Tronco
    s_Body.setPosition(trunkBody->GetPosition().x, trunkBody->GetPosition().y);
    s_Body.setRotation(trunkBody->GetAngle() * 180 / b2_pi);

    // Pierna izquierda
    s_Lleg.setPosition(leftLegBody->GetPosition().x, leftLegBody->GetPosition().y);
    s_Lleg.setRotation(leftLegBody->GetAngle() * 180 / b2_pi);

    // Pierna derecha
    s_Rleg.setPosition(rightLegBody->GetPosition().x, rightLegBody->GetPosition().y);
    s_Rleg.setRotation(rightLegBody->GetAngle() * 180 / b2_pi);

    // Brazo izquierdo
    s_Larm.setPosition(leftArmBody->GetPosition().x, leftArmBody->GetPosition().y);
    s_Larm.setRotation(leftArmBody->GetAngle() * 180 / b2_pi);

    // Brazo derecho
    s_Rarm.setPosition(rightArmBody->GetPosition().x, rightArmBody->GetPosition().y);
    s_Rarm.setRotation(rightArmBody->GetAngle() * 180 / b2_pi);
    /*std::cout << "Pos cabeza: ("
        << s_Head.getPosition().x << ", "
        << s_Head.getPosition().y << ")" << std::endl;
    std::cout << "Actualizando posiciones de sprites" << std::endl;*/
}
