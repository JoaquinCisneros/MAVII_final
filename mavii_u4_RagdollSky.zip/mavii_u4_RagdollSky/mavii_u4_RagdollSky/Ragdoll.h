#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <box2d/box2d.h>
#include "SFMLRenderer.h"
#include "Box2DHelper.h"
#include <iostream>

class Ragdoll {
private:
	b2World* world;

	b2Body* headBody;
	b2Body* trunkBody;
	b2Body* leftArmBody;
	b2Body* rightArmBody;
	b2Body* leftLegBody;
	b2Body* rightLegBody;

	b2DistanceJoint* headJoint;
	b2DistanceJoint* leftArmJoint;
	b2DistanceJoint* rightArmJoint;
	b2DistanceJoint* leftLegJoint;
	b2DistanceJoint* rightLegJoint;

	Texture t_Body;
	Texture t_Leg;
	Texture t_Arm;
	Texture t_Head;

	Sprite s_Body;
	Sprite s_Rleg;
	Sprite s_Lleg;
	Sprite s_Rarm;
	Sprite s_Larm;
	Sprite s_Head;
public:
	Ragdoll(b2World* world, const b2Vec2& position);
	void ApplyForceToBody(b2Vec2& force);
	void Update();
	void Draw(sf::RenderWindow& w);
};
