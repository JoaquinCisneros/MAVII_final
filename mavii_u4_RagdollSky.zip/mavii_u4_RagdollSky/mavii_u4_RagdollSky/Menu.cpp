#include "Menu.h"

Menu::Menu(){
    if (!font.loadFromFile("Assets/Fuentes/FuenteRegular.ttf")) {
        std::cerr << "Error loading cannon sound!" << std::endl;
    }

    playText.setFont(font);
    playText.setFillColor(sf::Color::White);
    playText.setString("Jugar");
    playText.setCharacterSize(36);
    playText.setPosition(100, 100);

    exitText.setFont(font);
    exitText.setFillColor(sf::Color::White);
    exitText.setString("Salir");
    exitText.setCharacterSize(36);
    exitText.setPosition(100, 160);

    if (!clickSBF.loadFromFile("Assets/Sounds/Menu_click.wav")) {
        std::cerr << "Error loading click sound!" << std::endl;
    }
    clickSound.setBuffer(clickSBF);
    clickSound.setVolume(10.0f);
}

void Menu::draw(sf::RenderWindow& wnd) {
    wnd.draw(playText);
    wnd.draw(exitText);
}

void Menu::handleInput(sf::Event& event, GameState& state, sf::RenderWindow& window) {
    if (event.type == sf::Event::MouseButtonPressed &&
        event.mouseButton.button == sf::Mouse::Left) {

        sf::Vector2f mousePos = window.mapPixelToCoords(
            sf::Vector2i(event.mouseButton.x, event.mouseButton.y)
        );

        if (playText.getGlobalBounds().contains(mousePos)) {
            clickSound.play();
            state = GameState::PLAYING;
        }
        else if (exitText.getGlobalBounds().contains(mousePos)) {
            clickSound.play();
            state = GameState::EXIT;
        }
    }
}
