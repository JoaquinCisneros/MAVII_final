#include "Menu.h"

Menu::Menu(){
    if (!font.loadFromFile("Assets/Fuentes/FuenteRegular.ttf")) {
        std::cerr << "Error loading cannon sound!" << std::endl;
    }

    Instrucciones = "Usa el click izquierdo para disparar mu�ecas.\nGolpea el blanco para avanzar de nivel.\nSi te quedas sin mu�ecas, el juego termina.\nPresiona ESC para volver al menu";
  
    playText.setFont(font);
    playText.setFillColor(sf::Color::White);
    playText.setString("Jugar");
    playText.setCharacterSize(36);
    playText.setPosition(100, 100);

    instructionsText.setFont(font);
    instructionsText.setFillColor(sf::Color::White);
    instructionsText.setString("Instrucciones");
    instructionsText.setCharacterSize(36);
    instructionsText.setPosition(100, 160);

    instructionsLongText.setFont(font);
    instructionsLongText.setFillColor(sf::Color::White);
    instructionsLongText.setString(Instrucciones);
    instructionsLongText.setCharacterSize(24);
    instructionsLongText.setPosition(100, 100);

    exitText.setFont(font);
    exitText.setFillColor(sf::Color::White);
    exitText.setString("Salir");
    exitText.setCharacterSize(36);
    exitText.setPosition(100, 220);

    gameOverText.setFont(font);
    gameOverText.setFillColor(sf::Color::Red);
    gameOverText.setString("FIN DEL JUEGO");
    gameOverText.setCharacterSize(48);
    gameOverText.setPosition(200, 150);

    restartText.setFont(font);
    restartText.setFillColor(sf::Color::White);
    restartText.setString("Presiona ESC para volver al menu");
    restartText.setCharacterSize(24);
    restartText.setPosition(gameOverText.getPosition().x, gameOverText.getPosition().y + 70);

    if (!clickSBF.loadFromFile("Assets/Sounds/Menu_click.wav")) {
        std::cerr << "Error loading click sound!" << std::endl;
    }
    clickSound.setBuffer(clickSBF);
    clickSound.setVolume(10.0f);
}

void Menu::draw(sf::RenderWindow& wnd) {
    wnd.draw(playText);
    wnd.draw(instructionsText);
    wnd.draw(exitText);
}

void Menu::drawInstructions(sf::RenderWindow& wnd) {
    wnd.draw(instructionsLongText);
    //std::cout << "Imprimiendo instrucciones en pantalla" << std::endl;
}

void Menu::drawGameOver(sf::RenderWindow& wnd) {
    wnd.draw(gameOverText);
    wnd.draw(restartText);
}

void Menu::handleInput(sf::Event& event, GameState& state, sf::RenderWindow& window) {
    if (event.type == sf::Event::MouseButtonPressed &&
        event.mouseButton.button == sf::Mouse::Left) {

        sf::Vector2f mousePos = window.mapPixelToCoords(
            sf::Vector2i(event.mouseButton.x, event.mouseButton.y)
        );

        if (playText.getGlobalBounds().contains(mousePos)) {
            clickSound.play();
            state = GameState::PLAYING;
        }
        else if (exitText.getGlobalBounds().contains(mousePos)) {
            clickSound.play();
            state = GameState::EXIT;
        }
        else if (instructionsText.getGlobalBounds().contains(mousePos)) {
            clickSound.play();
            state = GameState::INSTRUCTIONS;
        }
    }
}
