#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include "SFMLRenderer.h"
#include "Ragdoll.h"
#include <list>

using namespace sf;
class Game
{
private:
	//Propiedades de la ventana
	int alto;
	int ancho;
	RenderWindow *wnd;
	Color clearColor;

	//objetos de box2d
	b2World *phyWorld;
	SFMLRenderer *debugRender;

	//tiempo de frame
	float frameTime;
	int fps;

	//cuerpo de box2d 
	b2Body* canyonBody;
	b2Body* dynamicObstacle;
	//Disparo

	sf::Vector2f pos;
	b2Vec2 mousePos;
	b2Vec2 direction;

	//SFX

	sf::SoundBuffer cannonSBF;
	sf::SoundBuffer victorySBF;
	sf::Sound cannonSound;
	sf::Sound victorySound;

	bool victoryAchieved = false;
	bool begin = false;
	
	sf::Texture texturaPelota;
		
	std::vector<Ragdoll*> ragdolls;

public:

	//Constructores, destructores e inicializadores
	Game(int ancho, int alto,std::string titulo);
	~Game();
	void InitPhysics();

	//Main game loop
	void Loop();
	void DrawGame();
	void UpdatePhysics();
	void DoEvents();
	void SetZoom();
	void CheckVictoryCondition();
	
	//Metodo de disparo

	void ShootRagdoll(b2Vec2& position, b2Vec2& force);
	
};

