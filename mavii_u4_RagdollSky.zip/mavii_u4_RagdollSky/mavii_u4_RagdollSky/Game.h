#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include "Box2DHelper.h"
#include "SFMLRenderer.h"
#include "GameState.h"
#include "Menu.h"
#include "LevelManager.h"
#include "MyContactListener.h"
#include "LifeCounter.h"

using namespace sf;
using namespace std;
class Game
{
private:
	//Propiedades de la ventana
	int alto;
	int ancho;
	RenderWindow *wnd;
	Color clearColor;

	//objetos de box2d
	b2World *phyWorld;
	SFMLRenderer *debugRender;
	MyContactListener* contactListener;

	//tiempo de frame
	float frameTime;
	int fps;

	//SFX
	Music mainTheme;

	SoundBuffer victorySBF;
	Sound victorySound;

	SoundBuffer gameOverSBF;
	Sound gameOverSound;

	bool victoryAchieved = false;
	bool begin = false;

	GameState currentState;
	Menu* menu;
	LifeCounter* counter;

	//LevelManager
	LevelManager* levelManager;
	bool levelLoaded;
	int currentLevel;

	//Contador ragdolls
	int ragdollCount;


	Texture counterTexture;
	Sprite counterSprite;
	vector<Sprite> lives;


public:

	//Constructores, destructores e inicializadores
	Game(int ancho, int alto,std::string titulo);
	~Game();
	void InitPhysics();

	//Main game loop
	void Loop();
	void DrawGame();
	void UpdatePhysics();
	void DoEvents();
	void SetZoom();
	void SetVictory();
	void LoadLevel(int levelNumber); //funcion para cargar los distintos niveles
	void CleanPhysics();//Limpiar el mundo b2d entre niveles o menues
	void CleanWorld();
	void ResetWorld();

	
};

