#pragma once
#include "Ragdoll.h"
#include <SFML/Audio.hpp>
#include <list>
class Cannon
{
private:
	b2World& world;
	b2Body* canyonBody;
	Texture cannonTexture;
	Sprite cannonSprite;
	SoundBuffer cannonSBF;
	Sound cannonSound;
	std::vector<Ragdoll*> ragdolls;
	int ragdollCount;

public:
	Cannon(b2World& phyWorld);
	void ShootRagdoll(b2Vec2& position, b2Vec2& force);
	void Draw(RenderWindow& w);
	void HandleClick(Vector2f mousePosition);
};

