#include "Cannon.h"

Cannon::Cannon(b2World* phyWorld) : world(phyWorld){
    if (!cannonSBF.loadFromFile("Assets/Sounds/Cannon.wav")) {
        std::cerr << "Error loading cannon sound!" << std::endl;
    }

    if (!cannonTexture.loadFromFile("Assets/Sprites/Cannon.png")) {
        std::cerr << "Error loading cannon sprite!" << std::endl;
    }
    cannonSound.setBuffer(cannonSBF);

    //CA�ON

    //Setear body del ca�on

    canyonBody = Box2DHelper::CreateRectangularKinematicBody(world, 15.0f, 8.0f);
    canyonBody->SetTransform(b2Vec2(15.0f, 90.0f), 0);

    //Dibujo

    cannonSprite.setTexture(cannonTexture);
    //Setear origen y escala

    sf::Vector2f cannonSize(15.0f, 8.0f);

    float scaleX = 25.0f / cannonTexture.getSize().x;
    float scaleY = 13.0f / cannonTexture.getSize().y;

    cannonSprite.setScale(scaleX, scaleY);

    cannonSprite.setOrigin(cannonTexture.getSize().x / 2, cannonTexture.getSize().y / 2);
    cannonSprite.setPosition(canyonBody->GetPosition().x, canyonBody->GetPosition().y);
    cannonSprite.setRotation(canyonBody->GetAngle() * 180 / b2_pi);

}

void Cannon::ShootRagdoll(b2Vec2& position, b2Vec2& force) {
    Ragdoll* ragdoll = new Ragdoll(world, position); // Crear en heap
    ragdoll->ApplyForceToBody(force);
    cannonSound.play();
    std::cout << "se disparo un ragdoll" << std::endl;
    ragdollCount++;
    ragdolls.push_back(ragdoll); // Guardar para actualizar y dibujar luego
}

void Cannon::HandleClick(sf::Vector2f mousePosition) {
    b2Vec2 canyonPos = canyonBody->GetPosition();

    // Convertimos la posici�n del mouse a mundo
    b2Vec2 worldMousePos(mousePosition.x, mousePosition.y);

    // Direcci�n y distancia
    b2Vec2 direction = worldMousePos - canyonPos;
    float distance = direction.Normalize();

    // Rotamos el ca��n
    float angle = atan2(direction.y, direction.x);
    canyonBody->SetTransform(canyonBody->GetPosition(), angle);

    // Fuerza basada en la distancia
    float forceMagnitude = 500.0f * (1.0f - distance);
    b2Vec2 force = forceMagnitude * direction;

    // Spawn position del ragdoll
    b2Vec2 spawnPos(canyonPos.x + 10, canyonPos.y - 10);

    // Invertimos fuerza si es necesario
    b2Vec2 finaleForce(-force.x, -force.y);

    // Disparar
    ShootRagdoll(spawnPos, finaleForce);
}

void Cannon::Draw(RenderWindow& w) {
    //Update de ragdolls aca porque se dibuja todo el tiempo nada mas
    for (auto& ragdoll : ragdolls) {
        ragdoll->Update();
    }
    for (auto& ragdoll : ragdolls) {
        ragdoll->Draw(w);
    }
    UpdateCannon();
    w.draw(cannonSprite);
}

void Cannon::UpdateCannon() {
    cannonSprite.setRotation(canyonBody->GetAngle() * 180 / b2_pi);
}

b2World* Cannon::getCanonWorld() {
    return world;
}

void Cannon::SetCannonPosition(float x, float y) {
    canyonBody->SetTransform(b2Vec2(x, y), 0);
    cannonSprite.setPosition(canyonBody->GetPosition().x, canyonBody->GetPosition().y);
}
