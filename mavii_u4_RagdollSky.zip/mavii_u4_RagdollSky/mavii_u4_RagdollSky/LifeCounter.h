#include <SFML/Graphics.hpp>
class LifeCounter {
public:
    LifeCounter(const sf::Texture& texture, int totalLives, sf::Vector2f startPos)
        : texture(texture), totalLives(totalLives) {
        counterSprite.setTexture(this->texture);
        counterSprite.setScale(0.02, 0.02);
        for (int i = 0; i < totalLives; ++i) addLife(startPos);
    }

    void loseLife() { if (!lives.empty()) lives.pop_back(); }
    void addLife(sf::Vector2f startPos) {
        if ((int)lives.size() < totalLives) {
            sf::Sprite life(counterSprite);
            life.setPosition(startPos.x + lives.size() * (counterSprite.getGlobalBounds().width + 2.f), startPos.y);
            lives.push_back(life);
        }
    }

    void draw(sf::RenderWindow& window) {
        for (auto& life : lives)
            window.draw(life);
    }

private:
    const sf::Texture& texture;
    sf::Sprite counterSprite;
    int totalLives;
    std::vector<sf::Sprite> lives;
};


