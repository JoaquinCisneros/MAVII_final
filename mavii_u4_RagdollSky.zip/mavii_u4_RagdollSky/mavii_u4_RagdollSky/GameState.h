#pragma once
enum class GameState {
    MENU,
    INSTRUCTIONS,
    PLAYING,
    LEVEL_COMPLETE,
    GAME_OVER,
    EXIT
};
