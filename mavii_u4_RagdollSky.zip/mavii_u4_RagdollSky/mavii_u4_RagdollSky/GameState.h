#pragma once
enum class GameState {
    MENU,
    PLAYING,
    LEVEL_COMPLETE,
    GAME_OVER,
    EXIT
};
