#pragma once
#include "Cannon.h"
#include <iostream>
#include "Box2DHelper.h"
class LevelManager
{
	
private:
	b2World* world;
	Cannon* cannon;
	//cuerpo de box2d 
	b2Body* platform1;
	b2Body* dynamicObstacle; //el target
	b2Body* topWallBody;
	b2Body* groundBody;
	b2Body* leftWallBody;
	b2Body* rightWallBody;

	//SFML
	RectangleShape topWallShape;
	RectangleShape groundShape;
	RectangleShape leftWallShape;
	RectangleShape rightWallShape;

	RectangleShape platformShape;

	Texture targetTexture;
	Sprite targetSprite;


public:
	LevelManager(b2World *phyWorld);
	void LoadLevel(int level);
	void DrawLevel(RenderWindow& w);
	Cannon* GetCannon();
	b2World* getWorld();

};

