#pragma once
#include "Cannon.h"
#include "Box2DHelper.h"
class LevelManager
{
	
private:
	b2World& world;
	Cannon* cannon;
	//cuerpo de box2d 
	b2Body* dynamicObstacle;
	b2Body* topWallBody;
	b2Body* groundBody;
	b2Body* leftWallBody;
	b2Body* rightWallBody;

	//SFML
	RectangleShape* topWallShape;
	RectangleShape* groundShape;
	RectangleShape* leftWallShape;
	RectangleShape* rightWallShape;

	Texture targetTexture;
	Sprite targetSprite;


public:
	LevelManager(b2World& phyWorld);
	void LoadLevel(int level);
	void DrawLevel(RenderWindow& w);
	Cannon* GetCannon();

};

