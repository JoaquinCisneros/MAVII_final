#pragma once
#include "Cannon.h"
#include <iostream>
#include "Box2DHelper.h"
#include <vector>
class LevelManager
{
	
private:
	b2World* world;
	Cannon* cannon;
	//cuerpo de box2d 
	b2Body* platform1;
	b2Body* targetBody; //el target
	b2Body* topWallBody;
	b2Body* groundBody;
	b2Body* leftWallBody;
	b2Body* rightWallBody;
	b2Body* movableObstacle;
	b2Body* movableObstacle2;

	//SFML
	RectangleShape topWallShape;
	RectangleShape groundShape;
	RectangleShape leftWallShape;
	RectangleShape rightWallShape;

	RectangleShape platformShape;

	Texture targetTexture;
	Texture obstacleTexture;
	Texture background1_t;
	Texture background2_t;
	Sprite background1, background2;
	Sprite targetSprite;
	Sprite topObstacleSprite, botObstacleSprite, movableObstacleSprite, axisSprite, movableObstacleSprite2, axisSprite2;

	std::vector<Sprite> levelSprites;

	//Contador de ragdolls


public:
	LevelManager(b2World *phyWorld);
	void LoadLevel(int level);
	void DrawLevel(RenderWindow& w);
	void UpdateSpritePositions();
	void SetWorld(b2World* newWorld);
	Cannon* GetCannon();
	b2World* getWorld();
	void CreateBodys(b2World* world);
	void HideSprites();

};

