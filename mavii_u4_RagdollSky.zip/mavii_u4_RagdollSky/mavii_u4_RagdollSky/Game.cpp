#include "Game.h"

// Constructor de la clase Game
Game::Game(int ancho, int alto, std::string titulo)
{
    // Inicializaci�n de la ventana de renderizado
    wnd = new RenderWindow(VideoMode(ancho, alto), titulo);
    wnd->setVisible(true);
    fps = 60;
    wnd->setFramerateLimit(fps);
    frameTime = 1.0f / fps;
    InitPhysics(); // Inicializaci�n del mundo f�sico

    menu = new Menu();
    currentState == GameState::MENU;

    levelManager = new LevelManager(*phyWorld);

    int currentLevel = 0;
    levelLoaded1 = false;

    // Cargar el archivo de sonido
    if (!victorySBF.loadFromFile("Assets/Sounds/Win.wav")) {
        std::cerr << "Error loading Win sound!" << std::endl;
    }
    victorySound.setBuffer(victorySBF);
}

// M�todo principal que maneja el bucle del juego
void Game::Loop()
{
    while (wnd->isOpen())
    {
        wnd->clear(clearColor); // Limpia la ventana con un color especificado
        DoEvents(); // Procesa los eventos del sistema
        UpdatePhysics(); // Actualiza la simulaci�n f�sica
        DrawGame(); // Dibuja el juego en la ventana
        wnd->display(); // Muestra la ventana renderizada
    }
}

// Dibuja los elementos del juego en la ventana
void Game::DrawGame()
{  
    if (currentState == GameState::MENU) { //Si el estado es "menu" dibujar el menu
        menu->draw(*wnd);
    }
    if (currentState == GameState::PLAYING) { //Si estado jugar, dibujar el juego

        phyWorld->DebugDraw();

        levelManager->DrawLevel(*wnd);

    }
}

// Procesa los eventos del sistema
void Game::DoEvents()
{
    Event evt;
    while (wnd->pollEvent(evt))
    {
        switch (evt.type)
        {
        case Event::Closed:
            wnd->close(); // Cierra la ventana
            break;
        case Event::KeyPressed:
            //Imputs del usuario
            break;
        case Event::MouseButtonPressed:

            if (currentState == GameState::MENU) {
                menu->handleInput(evt, currentState, *wnd);
            }

            if (currentState == GameState::EXIT) {
                wnd->close();
            }

            if (currentState == GameState::PLAYING) { //Si se esta jugando:

                SetZoom(); // Configuraci�n del zoom de la c�mara
                if (!levelLoaded1) {
                    LoadLevel(1);
                    levelLoaded1 = true;
                }

                Vector2f mousePos = wnd->mapPixelToCoords(Vector2i(evt.mouseButton.x, evt.mouseButton.y));
                levelManager->GetCannon()->HandleClick(mousePos);
                //ragdollCount++;

                break;
            
            }
        }
    }
}

// Configura el �rea visible en la ventana de renderizado
void Game::SetZoom()
{
    View camara;
    camara.setSize(100.0f, 100.0f); // Tama�o del �rea visible
    camara.setCenter(50.0f, 50.0f); // Centra la vista en estas coordenadas
    wnd->setView(camara); // Asigna la vista a la ventana
}

// Inicializa el mundo f�sico y los elementos est�ticos del juego
void Game::InitPhysics()
{
    // Inicializa el mundo f�sico con la gravedad por defecto
    phyWorld = new b2World(b2Vec2(0.0f, 9.8f));

    // Inicializa el renderizador de depuraci�n para el mundo f�sico

    debugRender = new SFMLRenderer(wnd);
    debugRender->SetFlags(UINT_MAX); // Configura el renderizado para que muestre todo
    phyWorld->SetDebugDraw(debugRender);

    phyWorld->ClearForces(); // Limpia las fuerzas aplicadas a los cuerpos
}

// Actualiza la simulaci�n f�sica
void Game::UpdatePhysics()
{   
    phyWorld->Step(frameTime, 8, 8);
    if (currentState == GameState::PLAYING && !levelLoaded1) {//si se esta jugando y aun no se cargo el nivel, cargar el nivel:
        LoadLevel(1);
        ragdollCount = 0;
        levelLoaded1 = true;
        std::cout << "level loaded succsesfully";
    
    }
    if (currentState != GameState::PLAYING) {
        levelLoaded1 = false;
        //Esto rompe el juego por alguna razon
        //CleanPhysics(); // Cuando no se est� jugando, no necesitamos el mundo fisico
    }
    
    CheckVictoryCondition();
}

void Game::LoadLevel(int levelNumber) {
    InitPhysics();
    ragdollCount = 0;
    levelManager->LoadLevel(levelNumber);
    begin = true;
}


void Game::CheckVictoryCondition() {
    if (!victoryAchieved && begin && ragdollCount > 1 && dynamicObstacle->IsAwake()) {
        victoryAchieved = true;

        // Reproduc� el sonido y mostrale al jugador que gan�
        victorySound.play();
        std::cout << "�Victoria alcanzada!\n";
    }
    if (ragdollCount >= 5) { //Limite de ragdolls
        wnd->close();
    }
}

void Game::CleanPhysics() {
    if (phyWorld) {
        delete phyWorld;
        phyWorld = nullptr;
    }

    if (debugRender) {
        delete debugRender;
        debugRender = nullptr;
    }
}

Game::~Game() {
}

/*NOTAS:
    -(done a la mitad)Pegar sprites en los elementos de box2d
    -Generar una clase disparo y o una ca�on, para hacer correctamente la POO
    - Generar niveles extra utilizando otras propiedades de box2D (otros joints)
*/