#include "Game.h"

// Constructor de la clase Game
Game::Game(int ancho, int alto, std::string titulo)
{   
    InitPhysics(); // Inicializaci�n del mundo f�sico
    // Inicializaci�n de la ventana de renderizado
    wnd = new RenderWindow(VideoMode(ancho, alto), titulo);
    wnd->setVisible(true);
    fps = 60;
    wnd->setFramerateLimit(fps);
    frameTime = 1.0f / fps;

    menu = new Menu(); //Creo el menu
    currentState = GameState::MENU; // Seteo el estado de juego primeramente al Menu

    levelManager = new LevelManager(phyWorld);
    contactListener = new MyContactListener();
    phyWorld->SetContactListener(contactListener);
    cout << "Se asigno un mundo a levelManager: " << levelManager->getWorld() <<endl;

    currentLevel = 1;
    levelLoaded = false;

    // Cargar el archivo de sonido
    mainTheme.openFromFile("Assets/Sounds/Main.wav");
    mainTheme.setVolume(5.0f);
    mainTheme.setLoop(true);

    if (!victorySBF.loadFromFile("Assets/Sounds/Win.wav")) {
        std::cerr << "Error loading Win sound!" << std::endl;
    }
    victorySound.setBuffer(victorySBF);

    if (!gameOverSBF.loadFromFile("Assets/Sounds/GameOver.wav")) {
        std::cerr << "Error loading GO sound!" << std::endl;
    }
    gameOverSound.setBuffer(gameOverSBF);
    mainTheme.play();
}

// M�todo principal que maneja el bucle del juego
void Game::Loop()
{
    while (wnd->isOpen())
    {
        wnd->clear(clearColor); // Limpia la ventana con un color especificado
        DoEvents(); // Procesa los eventos del sistema
        UpdatePhysics(); // Actualiza la simulaci�n f�sica
        DrawGame(); // Dibuja el juego en la ventana
        wnd->display(); // Muestra la ventana renderizada
    }
}

// Dibuja los elementos del juego en la ventana
void Game::DrawGame()
{  
    if (currentState == GameState::MENU) { //Si el estado es "menu" dibujar el menu
        menu->draw(*wnd);
    }
    if (currentState == GameState::PLAYING) { //Si estado jugar, dibujar el juego

        //phyWorld->DebugDraw();

        levelManager->DrawLevel(*wnd);

    }
}

// Procesa los eventos del sistema
void Game::DoEvents()
{
    Event evt;
    while (wnd->pollEvent(evt))
    {
        switch (evt.type)
        {
        case Event::Closed:
            wnd->close(); // Cierra la ventana
            break;

        case Event::KeyPressed:
            //Imputs del usuario
            break;

        case Event::MouseButtonPressed:

            if (currentState == GameState::MENU) {
                menu->handleInput(evt, currentState, *wnd);
            }

            if (currentState == GameState::EXIT) {
                wnd->close();
            }

            if (currentState == GameState::PLAYING) { //Si se esta jugando:

                SetZoom(); // Configuraci�n del zoom de la c�mara          
                
                if (begin) {
                    Vector2f mousePos = wnd->mapPixelToCoords(Vector2i(evt.mouseButton.x, evt.mouseButton.y));
                    levelManager->GetCannon()->HandleClick(mousePos);
                    ragdollCount++;
                }
                cout << "hay ragdolls: " << ragdollCount << endl;

                break;
            
            }
        }
    }
}

// Configura el �rea visible en la ventana de renderizado
void Game::SetZoom()
{
    View camara;
    camara.setSize(100.0f, 100.0f); // Tama�o del �rea visible
    camara.setCenter(50.0f, 50.0f); // Centra la vista en estas coordenadas
    wnd->setView(camara); // Asigna la vista a la ventana
}

// Inicializa el mundo f�sico y los elementos est�ticos del juego
void Game::InitPhysics()
{
    // Inicializa el mundo f�sico con la gravedad por defecto
    phyWorld = new b2World(b2Vec2(0.0f, 9.8f));
    if (phyWorld) {
        std::cout << "se creo mundo fisico" << std::endl;
    }
    std::cout << "phyWorld apunta a: " << phyWorld << std::endl;

    // Inicializa el renderizador de depuraci�n para el mundo f�sico

    debugRender = new SFMLRenderer(wnd);
    debugRender->SetFlags(UINT_MAX); // Configura el renderizado para que muestre todo
    phyWorld->SetDebugDraw(debugRender);
    std::cout << "debugRenderer:" << debugRender << std::endl;

}

// Actualiza la simulaci�n f�sica
void Game::UpdatePhysics()
{
    if (currentState != GameState::PLAYING)
        return;  // No actualizar f�sica si no estamos jugando

    phyWorld->Step(frameTime, 8, 8);

    if (!phyWorld) {
        cout << "se borro el mundo fisico" << endl;
    }

    if (!levelLoaded) {
        LoadLevel(currentLevel);
        levelLoaded = true;
        std::cout << "level loaded succsesfully";
    }

    if (ragdollCount > 5) {
        gameOverSound.play();
        currentState = GameState::GAME_OVER;
        return;
    }

    if (contactListener->IsVictoryDetected()) {
        contactListener->ResetVictoryFlag();
        SetVictory();
    }

    phyWorld->ClearForces();
}

void Game::SetVictory() {
    if (!victoryAchieved) {
        victoryAchieved = true;
        std::cout << "Victoria!" << endl;
        victorySound.play(); //sonido de ganar
        currentLevel++; //pasamos de nivel

        if (currentLevel <= 3) { //si todavia hay niveles, cargar el siguiente
            ResetWorld(); //primero eliminamos el mundo anterior, creamos el nuevo y asignamos la referencia en el levelmanager para crear el nivel nuevamente
            LoadLevel(currentLevel);//una vez borrado y creado el mundo, cargamos el nivel en el mundo vacio
        }
    }
}

void Game::LoadLevel(int levelNumber) {
    //CleanWorld();
    ragdollCount = 0;
    victoryAchieved = false;
    levelManager->LoadLevel(levelNumber);
    begin = true;
}



void Game::CleanWorld() {
    // Recorre todos los cuerpos y los destruye
    b2Body* body = phyWorld->GetBodyList();
    while (body) {
        b2Body* next = body->GetNext();
        phyWorld->DestroyBody(body);
        body = next;
    }
}

void Game::CleanPhysics() {
    if (phyWorld) {
        delete phyWorld;
        phyWorld = nullptr;
    }

    if (debugRender) {
        delete debugRender;
        debugRender = nullptr;
    }

    if (levelManager) {
        delete levelManager;
        levelManager = nullptr;
    }

}

void Game::ResetWorld() {
    delete phyWorld;
    phyWorld = new b2World(b2Vec2(0.0f, 9.8f));
    phyWorld->SetDebugDraw(debugRender);
    phyWorld->SetContactListener(contactListener);

    // actualizar el levelManager con el nuevo mundo
    levelManager->SetWorld(phyWorld);
}

Game::~Game() {
    CleanPhysics();
    delete wnd;
    delete menu;
}

/*NOTAS:
    -(done a la mitad)Pegar sprites en los elementos de box2d
    -Generar una clase disparo y o una ca�on, para hacer correctamente la POO
    - Generar niveles extra utilizando otras propiedades de box2D (otros joints)
*/