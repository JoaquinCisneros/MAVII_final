#include "Game.h"

// Constructor de la clase Game
Game::Game(int ancho, int alto, std::string titulo)
{   
    InitPhysics(); // Inicializaci�n del mundo f�sico
    // Inicializaci�n de la ventana de renderizado
    wnd = new RenderWindow(VideoMode(ancho, alto), titulo);
    wnd->setVisible(true);
    fps = 60;
    wnd->setFramerateLimit(fps);
    frameTime = 1.0f / fps;

    //Creo el contador
    counterTexture.loadFromFile("Assets/Sprites/Cabeza.png");

    counter = new LifeCounter(counterTexture, 5, { 5.0f, 5.0f });


    menu = new Menu(); //Creo el menu
    currentState = GameState::MENU; // Seteo el estado de juego primeramente al Menu

    levelManager = new LevelManager(phyWorld); //El manager que cambia los niveles
    contactListener = new MyContactListener(); //Para las colisiones
    phyWorld->SetContactListener(contactListener);
    //cout << "Se asigno un mundo a levelManager: " << levelManager->getWorld() <<endl; //para debug

    currentLevel = 1;
    levelLoaded = false;

    // Cargar el archivo de sonido
    mainTheme.openFromFile("Assets/Sounds/Main.wav");
    mainTheme.setVolume(5.0f);
    mainTheme.setLoop(true);

    if (!victorySBF.loadFromFile("Assets/Sounds/Win.wav")) {
        std::cerr << "Error loading Win sound!" << std::endl;
    }
    victorySound.setBuffer(victorySBF);

    if (!gameOverSBF.loadFromFile("Assets/Sounds/GameOver.wav")) {
        std::cerr << "Error loading GO sound!" << std::endl;
    }
    gameOverSound.setBuffer(gameOverSBF);
    mainTheme.play();
}

// M�todo principal que maneja el bucle del juego
void Game::Loop()
{
    while (wnd->isOpen())
    {
        wnd->clear(clearColor); // Limpia la ventana con un color especificado
        DoEvents(); // Procesa los eventos del sistema
        UpdatePhysics(); // Actualiza la simulaci�n f�sica
        DrawGame(); // Dibuja el juego en la ventana
        wnd->display(); // Muestra la ventana renderizada
    }
}

// Dibuja los elementos del juego en la ventana
void Game::DrawGame()
{  
    if (currentState == GameState::MENU) { //Si el estado es "menu" dibujar el menu
        menu->draw(*wnd);
    }
    if (currentState == GameState::INSTRUCTIONS) {
        menu->drawInstructions(*wnd);
    }
    if (currentState == GameState::GAME_OVER) {
        menu->drawGameOver(*wnd);
    }
    if (currentState == GameState::PLAYING) { //Si estado jugar, dibujar el juego

        //phyWorld->DebugDraw();

        
        levelManager->UpdateSpritePositions();
        levelManager->DrawLevel(*wnd);//Dibujo el nivel
        counter->draw(*wnd);//Dibujo el contador

    }
}

// Procesa los eventos del sistema
void Game::DoEvents()
{
    Event evt;
    while (wnd->pollEvent(evt))
    {
        switch (evt.type)
        {
        case Event::Closed:
            wnd->close(); // Cierra la ventana
            break;

        case Event::KeyPressed:
            if (evt.key.code == sf::Keyboard::Escape) {
                if (currentState != GameState::MENU && currentState != GameState::PLAYING) {
                    currentState = GameState::MENU;
                    ResetZoom();

                    begin = true;

                }
            }
            //Imputs del usuario
            break;

        case Event::MouseButtonPressed:

            if (currentState == GameState::MENU) {
                menu->handleInput(evt, currentState, *wnd); //manejar clicks en el menu
            }
            
            if (currentState == GameState::EXIT) {
                wnd->close();
            }

            if (currentState == GameState::PLAYING) { //Si se esta jugando:

                SetZoom(); // Configuraci�n del zoom de la c�mara          
                
                if (begin) { //Jugando, el click es el disparo
                    Vector2f mousePos = wnd->mapPixelToCoords(Vector2i(evt.mouseButton.x, evt.mouseButton.y));
                    levelManager->GetCannon()->HandleClick(mousePos); //Delegamos al objeto ca�on
                    ragdollCount--; //Restamos un disparo
                    counter->loseLife(); //Y actualizamos el contador
                }
                
                //cout << "hay ragdolls: " << ragdollCount << endl; //para debug

                break;
            
            }
        }
    }
}

// Configura el �rea visible en la ventana de renderizado
void Game::SetZoom()
{
    View camara;
    camara.setSize(100.0f, 100.0f); // Tama�o del �rea visible
    camara.setCenter(50.0f, 50.0f); // Centra la vista en estas coordenadas
    wnd->setView(camara); // Asigna la vista a la ventana
}

void Game::ResetZoom() 
{
    wnd->setView(wnd->getDefaultView());
}

// Inicializa el mundo f�sico y los elementos est�ticos del juego
void Game::InitPhysics()
{
    // Inicializa el mundo f�sico con la gravedad por defecto
    phyWorld = new b2World(b2Vec2(0.0f, 9.8f));
    if (phyWorld) {
        //std::cout << "se creo mundo fisico" << std::endl; //para debug
    }
    //std::cout << "phyWorld apunta a: " << phyWorld << std::endl; // para debug

    // Inicializa el renderizador de depuraci�n para el mundo f�sico

    debugRender = new SFMLRenderer(wnd);
    debugRender->SetFlags(UINT_MAX); // Configura el renderizado para que muestre todo
    phyWorld->SetDebugDraw(debugRender);
    //std::cout << "debugRenderer:" << debugRender << std::endl; //para debug

}

// Actualiza la simulaci�n f�sica
void Game::UpdatePhysics()
{
    if (currentState != GameState::PLAYING){
        return;
    }// No actualizar f�sica si no estamos jugando

    phyWorld->Step(frameTime, 8, 8);

    if (!phyWorld) {
        cout << "se borro el mundo fisico" << endl;
    } //para debug

    if (!levelLoaded) {
        LoadLevel(currentLevel);
        levelLoaded = true;
        cout << "Se cargo el nivel correctamente" << endl;
    }

    if (ragdollCount < 0) { //Si se dispara con 0 ragdolls, se pierde
        gameOverSound.play();
        ResetZoom();
        currentState = GameState::GAME_OVER;
        victoryAchieved = false; //Resetar bandera
        ragdollCount = 5; //Reseteamos los ragdolls
        counter->resetLives();
        begin = 0;
        CleanWorld();
        ResetWorld();
        return;
    }

    if (contactListener->IsVictoryDetected()) { //preguntamos en el contactListener, y avisamos para setear victoria
        contactListener->ResetVictoryFlag();
        SetVictory();
    }

    phyWorld->ClearForces(); //Limpiamos en cada step
}

void Game::SetVictory() {
    if (!victoryAchieved) {
        victoryAchieved = true;
        std::cout << "Victoria!" << endl;
        victorySound.play(); //sonido de ganar
        currentLevel++; //pasamos de nivel

        if (currentLevel <= 3) { //si todavia hay niveles, cargar el siguiente
            ResetWorld(); //primero eliminamos el mundo anterior, creamos el nuevo y asignamos la referencia en el levelmanager para crear el nivel nuevamente
            LoadLevel(currentLevel);//una vez borrado y creado el mundo, cargamos el nivel en el mundo vacio
        }
    }
}

void Game::LoadLevel(int levelNumber) {
    //CleanWorld();
    ragdollCount = 5; //Reseteamos las ragdolls
    counter->resetLives(); // Y el contador
    victoryAchieved = false; //La bandera de victoria, para poder ganar nuevamente
    levelManager->LoadLevel(levelNumber); //Finalmente cargamos el nivel correspondiente
    begin = true;
}



void Game::CleanWorld() {
    // Recorre todos los cuerpos y los destruye
    b2Body* body = phyWorld->GetBodyList();
    while (body) {
        b2Body* next = body->GetNext();
        phyWorld->DestroyBody(body);
        body = next;
    }
}

void Game::CleanPhysics() {
    if (phyWorld) {
        delete phyWorld;
        phyWorld = nullptr;
    }

    if (debugRender) {
        delete debugRender;
        debugRender = nullptr;
    }

    if (levelManager) {
        delete levelManager;
        levelManager = nullptr;
    }

}

void Game::ResetWorld() {
    delete phyWorld;
    phyWorld = new b2World(b2Vec2(0.0f, 9.8f));
    phyWorld->SetDebugDraw(debugRender);
    phyWorld->SetContactListener(contactListener);

    // actualizar el levelManager con el nuevo mundo
    levelManager->SetWorld(phyWorld);
}

Game::~Game() {
    CleanPhysics();
    delete wnd;
    delete menu;
}

/*NOTAS:
    -(done a la mitad)Pegar sprites en los elementos de box2d
    -Generar una clase disparo y o una ca�on, para hacer correctamente la POO
    - Generar niveles extra utilizando otras propiedades de box2D (otros joints)
*/