#include "LevelManager.h"

LevelManager::LevelManager(b2World* phyWorld) : world(phyWorld) {

    cannon = new Cannon(world);

    topWallBody = Box2DHelper::CreateRectangularStaticBody(world, 100, 5);
    groundBody = Box2DHelper::CreateRectangularStaticBody(world, 100, 5);
    leftWallBody = Box2DHelper::CreateRectangularStaticBody(world, 5, 100);
    rightWallBody = Box2DHelper::CreateRectangularStaticBody(world, 5, 100);
    dynamicObstacle = Box2DHelper::CreateRectangularStaticBody(world, 7.0f, 15.0f);
    dynamicObstacle->GetUserData().pointer = reinterpret_cast<uintptr_t>("target");


    topWallBody->SetTransform(b2Vec2(50.0f, -2.0f), 0.0f);
    groundBody->SetTransform(b2Vec2(50.0f, 102.0f), 0.0f);
    leftWallBody->SetTransform(b2Vec2(-2.0f, 50.0f), 0.0f);
    rightWallBody->SetTransform(b2Vec2(102.0f, 50.0f), 0.0);

    //SFML

    if (!targetTexture.loadFromFile("Assets/Sprites/Target.png")) {
        std::cerr << "Error loading Win sound!" << std::endl;
    }

    targetSprite.setTexture(targetTexture);

    ///*s_Head.setPosition(headBody->GetPosition().x, headBody->GetPosition().y);

    // Dibujamos el suelo y las paredes
    groundShape.setSize(sf::Vector2f(100, 5));
    groundShape.setFillColor(sf::Color::Red);
    groundShape.setPosition(groundBody->GetPosition().x, groundBody->GetPosition().y);
    groundShape.setOrigin(50, 2.5f);

    leftWallShape.setSize(sf::Vector2f(5, 100));
    leftWallShape.setFillColor(sf::Color::Red);
    leftWallShape.setPosition(leftWallBody->GetPosition().x, leftWallBody->GetPosition().y);
    leftWallShape.setOrigin(2.5f, 50.0f);

    rightWallShape.setSize(sf::Vector2f(5, 100));
    rightWallShape.setFillColor(sf::Color::Red);
    rightWallShape.setPosition(rightWallBody->GetPosition().x, rightWallBody->GetPosition().y);
    rightWallShape.setOrigin(2.5f, 50.0f);

    topWallShape.setSize(sf::Vector2f(100, 5));
    topWallShape.setFillColor(sf::Color::Red);
    topWallShape.setPosition(topWallBody->GetPosition().x, topWallBody->GetPosition().y);
    topWallShape.setOrigin(50.0f, 2.5f);
    std::cout << "el cannon se encuentra en el mundo: " << cannon->getCanonWorld() << std::endl;

}

void LevelManager::LoadLevel(int levelNumber) {
    std::cout << "cargando nivel: " << levelNumber << std::endl;
    switch (levelNumber) {
        
    case 1: { // Nivel 1
        //OBSTACULOS

        //Fijos

        b2Body* topRigidObstacle = Box2DHelper::CreateRectangularStaticBody(world, 4.0f, 30.0f);
        topRigidObstacle->SetTransform(b2Vec2(55.0f, 15.0f), 0.0f);
        b2Body* botRigidObstacle = Box2DHelper::CreateRectangularStaticBody(world, 4.0f, 40.0f);
        botRigidObstacle->SetTransform(b2Vec2(55.0f, 80.0f), 0.0f);

        //Dinamicos

        //Plataforma

        platform1 = Box2DHelper::CreateRectangularStaticBody(world, 20.0f, 20.0f);
        platform1->SetTransform(b2Vec2(85.0f, 90.0f), 0);

        platformShape.setSize(Vector2f(20.0f, 20.0f));
        platformShape.setFillColor(sf::Color::Green);
        platformShape.setOrigin(platformShape.getSize().x / 2, platformShape.getSize().y / 2);
        platformShape.setPosition(platform1->GetPosition().x, platform1->GetPosition().y);

        //Objeto movible
        dynamicObstacle->SetTransform(b2Vec2(platform1->GetPosition().x, platform1->GetPosition().y - 20.0f), 0.0f);
        std::cout << "SetTransform aplicado, posici�n actual: "
            << dynamicObstacle->GetPosition().x << ", "
            << dynamicObstacle->GetPosition().y << std::endl;

        break;
    }
    default:
        std::cout << "No se encuentra nivel" << std::endl;
    }
}

void LevelManager::DrawLevel(RenderWindow& w) {
    sf::Vector2f targetsize(7.0f, 15.0f);
    targetSprite.setOrigin(targetTexture.getSize().x / 2, targetTexture.getSize().y / 2);
    targetSprite.setScale((targetsize.x / targetTexture.getSize().x) * 2, (targetsize.y / targetTexture.getSize().y) * 1.5);
    targetSprite.setPosition(dynamicObstacle->GetPosition().x, dynamicObstacle->GetPosition().y);

    targetSprite.setRotation(dynamicObstacle->GetAngle() * 180 / b2_pi);

    w.draw(topWallShape);
    w.draw(groundShape);
    w.draw(leftWallShape);
    w.draw(rightWallShape);
    w.draw(platformShape);
    w.draw(targetSprite);
    cannon->Draw(w);
}

Cannon* LevelManager::GetCannon() {
    return cannon;
}

b2World* LevelManager::getWorld() { //para debug
    return world;
}